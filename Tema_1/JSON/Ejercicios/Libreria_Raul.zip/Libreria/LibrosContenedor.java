package Ejercicios.Libreria;

import java.util.List;

public class LibrosContenedor {
	private List<Libro> libros;

	public List<Libro> getLibros() {
		return libros;
	}

	public void setLibros(List<Libro> libros) {
		this.libros = libros;
	}
}