package Ejercicios.Ejercicio_42;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Libreria")
@XmlAccessorType(XmlAccessType.FIELD)

public class Libreria {

	@XmlAttribute(name = "nombre")
	private String nombre;

	@XmlAttribute(name = "lugar")
	private String lugar;

	@XmlAttribute(name = "cp")
	private int cp;

	@XmlElementWrapper(name = "listaLibreria")
	@XmlElement(name = "Libro")
	private ArrayList<Libro> listaLibreria = new ArrayList<>();

	public Libreria() {
	}

	public ArrayList<Libro> getLibreria() {
		return listaLibreria;
	}

	public void setLibreria(ArrayList<Libro> listaLibreria) {
		this.listaLibreria = listaLibreria;
	}

	// --- Getters y Setters para los atributos ---
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public int getCp() {
		return cp;
	}

	public void setCp(int cp) {
		this.cp = cp;
	}

	public void mostrarLibreria() {
		for (Libro libro : listaLibreria) {
			System.out.println(libro);
		}
	}

	public void aniadirLibro(Libro libro) {
		listaLibreria.add(libro);
	}
}
