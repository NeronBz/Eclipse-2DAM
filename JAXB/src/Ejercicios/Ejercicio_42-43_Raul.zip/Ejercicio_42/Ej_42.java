package Ejercicios.Ejercicio_42;

import java.io.File;
import java.util.Scanner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class Ej_42 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean continuar = true;
		Libreria libreria = new Libreria();

		// Pedir datos de la librería
		System.out.println("Introduce el nombre: ");
		String nombre = sc.nextLine();
		System.out.println("Introduce el lugar: ");
		String lugar = sc.nextLine();
		System.out.println("Introduce el CP: ");
		int cp = Integer.parseInt(sc.nextLine());

		libreria.setNombre(nombre);
		libreria.setLugar(lugar);
		libreria.setCp(cp);

		// Pedir datos de cada libro
		do {
			System.out.println("Introduce el titulo: ");
			String titulo = sc.nextLine();
			System.out.println("Introduce el autor: ");
			String autor = sc.nextLine();
			System.out.println("Introduce la editorial: ");
			String editorial = sc.nextLine();
			System.out.println("Introduce el ISBN: ");
			int isbn = Integer.parseInt(sc.nextLine());

			libreria.aniadirLibro(new Libro(titulo, autor, editorial, isbn));
			System.out.println("¿Añadir otro?");
			String respuesta = sc.nextLine();
			if (!respuesta.equalsIgnoreCase("si")) {
				continuar = false;
			}
		} while (continuar);

		sc.close();
		System.out.println("...................");
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Libreria.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal(libreria, System.out);
			marshaller.marshal(libreria, new File("src/Libreria.xml"));

		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
}
